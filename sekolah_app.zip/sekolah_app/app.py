from flask import Flask, render_template, request, redirect
import sqlite3
from flask import send_file
from openpyxl import Workbook
import io
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
import io

app = Flask(__name__)

# ======================
# DATABASE
# ======================
def get_db():
    conn = sqlite3.connect(
        "sekolah.db",
        timeout=10,
        check_same_thread=False
    )
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    db = get_db()

    db.execute("""
        CREATE TABLE IF NOT EXISTS pendaftar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            nisn TEXT,
            jenis_kelamin TEXT,
            tempat_lahir TEXT,
            tanggal_lahir TEXT,
            nik TEXT,
            kk TEXT,
            alamat TEXT,
            rt TEXT,
            rw TEXT,
            nama_ibu TEXT,
            nama_ayah TEXT,
            hp TEXT,
            status TEXT DEFAULT 'Pending'
        )
    """)

    db.commit()
    db.close()


init_db()

# ======================
# ROUTES
# ======================

@app.route('/')
def index():
    return render_template('index.html')


# tampil data + ranking umur
@app.route('/spmb')
def spmb():
    db = get_db()

    data = db.execute("""
        SELECT *,
        (
          strftime('%Y', 'now') - strftime('%Y', tanggal_lahir)
          - (strftime('%m-%d', 'now') < strftime('%m-%d', tanggal_lahir))
        ) as umur
        FROM pendaftar
        ORDER BY tanggal_lahir ASC
    """).fetchall()

    db.close()
    return render_template('spmb.html', data=data)


# form daftar
@app.route('/spmb/daftar')
def daftar():
    return render_template('daftar_spmb.html')


# simpan data
@app.route('/spmb/simpan', methods=['POST'])
def simpan():
    db = get_db()

    db.execute("""
        INSERT INTO pendaftar (nama, nisn, jenis_kelamin, tempat_lahir, tanggal_lahir, nik, kk, alamat, rt, rw, nama_ibu, nama_ayah, hp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?)
    """, (
        request.form['nama'],
        request.form['nisn'],
        request.form['jenis_kelamin'],
        request.form['tempat_lahir'],
        request.form['tanggal_lahir'],
        request.form['nik'],
        request.form['kk'],
        request.form['alamat'],
        request.form['rt'],
        request.form['rw'],
        request.form['nama_ibu'],
        request.form['nama_ayah'],
        request.form['hp'],
    ))

    db.commit()
    db.close()

    return redirect('/spmb')

# seleksi berdasarkan umur (kuota)
@app.route('/spmb/seleksi')
def seleksi():
    db = get_db()

    print("=== PROSES SELEKSI ===")

    # reset semua
    db.execute("UPDATE pendaftar SET status='Ditolak'")

    kuota = 2

    top = db.execute("""
        SELECT id FROM pendaftar
        ORDER BY tanggal_lahir ASC
        LIMIT ?
    """, (kuota,)).fetchall()

    print("DATA TERPILIH:", top)

    for t in top:
        db.execute(
            "UPDATE pendaftar SET status='Diterima' WHERE id=?",
            (t['id'],)
        )

    db.commit()
    db.close()

    return redirect('/spmb')

@app.route('/spmb/export')
def export_excel():
    db = get_db()

    data = db.execute("""
        SELECT *,
        (
          strftime('%Y', 'now') - strftime('%Y', tanggal_lahir)
          - (strftime('%m-%d', 'now') < strftime('%m-%d', tanggal_lahir))
        ) as umur
        FROM pendaftar
        ORDER BY tanggal_lahir ASC
    """).fetchall()

    db.close()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    import io

    wb = Workbook()

    # ======================
    # SHEET 1: SEMUA DATA
    # ======================
    ws = wb.active
    ws.title = "Semua Data"

    headers = [
        "Rank", "Nama", "NISN", "JK",
        "Tempat Lahir", "Tanggal Lahir", "Umur",
        "Alamat", "Ayah", "Ibu", "HP", "Status"
    ]
    ws.append(headers)

    # STYLE HEADER
    header_fill = PatternFill(start_color="4F81BD", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")

    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    # DATA
    for i, d in enumerate(data, start=1):
        ws.append([
            i,
            d['nama'],
            d['nisn'],
            d['jenis_kelamin'],
            d['tempat_lahir'],
            d['tanggal_lahir'],
            d['umur'],
            d['alamat'],
            d['nama_ayah'],
            d['nama_ibu'],
            d['hp'],
            d['status'],
        ])

    # WARNA STATUS
    for row in ws.iter_rows(min_row=2, max_col=12):
        status_cell = row[11]

        if status_cell.value == "Diterima":
            for cell in row:
                cell.fill = PatternFill(start_color="C6EFCE", fill_type="solid")

        elif status_cell.value == "Ditolak":
            for cell in row:
                cell.fill = PatternFill(start_color="FFC7CE", fill_type="solid")

    # AUTO WIDTH
    for col in ws.columns:
        max_length = 0
        col_letter = col[0].column_letter

        for cell in col:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))

        ws.column_dimensions[col_letter].width = max_length + 2

    # ======================
    # SHEET 2: DITERIMA
    # ======================
    ws2 = wb.create_sheet("Diterima")

    ws2.append(headers)

    for cell in ws2[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    no = 1
    for d in data:
        if d['status'] == "Diterima":
            ws2.append([
                no,
                d['nama'],
                d['nisn'],
                d['jenis_kelamin'],
                d['tempat_lahir'],
                d['tanggal_lahir'],
                d['umur'],
                d['alamat'],
                d['nama_ayah'],
                d['nama_ibu'],
                d['hp'],
                d['status'],
            ])
            no += 1

    # AUTO WIDTH SHEET 2
    for col in ws2.columns:
        max_length = 0
        col_letter = col[0].column_letter

        for cell in col:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))

        ws2.column_dimensions[col_letter].width = max_length + 2

    # ======================
    # SAVE
    # ======================
    file_stream = io.BytesIO()
    wb.save(file_stream)
    file_stream.seek(0)

    return send_file(
        file_stream,
        as_attachment=True,
        download_name="laporan_spmb.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@app.route('/spmb/pdf')
def export_pdf():
    db = get_db()

    data = db.execute("""
        SELECT *,
        (
          strftime('%Y', 'now') - strftime('%Y', tanggal_lahir)
          - (strftime('%m-%d', 'now') < strftime('%m-%d', tanggal_lahir))
        ) as umur
        FROM pendaftar
        ORDER BY tanggal_lahir ASC
    """).fetchall()

    db.close()

    buffer = io.BytesIO()

    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []

    styles = getSampleStyleSheet()

    # ======================
    # JUDUL
    # ======================
    elements.append(Paragraph("LAPORAN HASIL SELEKSI PPDB", styles['Title']))
    elements.append(Paragraph("SDN 01 BANGLARANGAN", styles['Heading2']))
    elements.append(Spacer(1, 12))

    # ======================
    # TABEL
    # ======================
    table_data = [
        ["No", "Nama", "NISN", "Umur", "Alamat", "Status"]
    ]

    for i, d in enumerate(data, start=1):
        table_data.append([
            i,
            d['nama'],
            d['nisn'],
            str(d['umur']) + " th",
            d['alamat'],
            d['status']
        ])

    table = Table(table_data)

    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.grey),
        ('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('GRID',(0,0),(-1,-1),1,colors.black),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ]))

    # WARNA STATUS
    for i, d in enumerate(data, start=1):
        if d['status'] == "Diterima":
            table.setStyle([
                ('BACKGROUND', (0,i), (-1,i), colors.lightgreen)
            ])
        elif d['status'] == "Ditolak":
            table.setStyle([
                ('BACKGROUND', (0,i), (-1,i), colors.pink)
            ])

    elements.append(table)

    # ======================
    # TANDA TANGAN
    # ======================
    elements.append(Spacer(1, 30))
    elements.append(Paragraph("Mengetahui,", styles['Normal']))
    elements.append(Spacer(1, 40))
    elements.append(Paragraph("Kepala Sekolah", styles['Normal']))
    elements.append(Spacer(1, 60))
    elements.append(Paragraph("(____________________)", styles['Normal']))

    # ======================
    # BUILD PDF
    # ======================
    doc.build(elements)

    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name="laporan_ppdb.pdf",
        mimetype="application/pdf"
    )
    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050, debug=True)