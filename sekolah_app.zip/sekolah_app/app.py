from flask import Flask, render_template, request, redirect, send_file
import sqlite3
import io

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.chart import BarChart, Reference

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet

app = Flask(__name__)

DB_NAME = "sekolah.db"


# ======================
# DATABASE
# ======================
def get_db():
    conn = sqlite3.connect(DB_NAME, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row

    # Anti database locked
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")

    return conn


def init_db():
    db = get_db()

    db.execute("""
        CREATE TABLE IF NOT EXISTS pendaftar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT,
            nisn TEXT,
            jenis_kelamin TEXT,
            tempat_lahir TEXT,
            tanggal_lahir TEXT,
            nik TEXT,
            kk TEXT,
            no_akta TEXT,
            asal_tk TEXT,
            alamat TEXT,
            rt TEXT,
            rw TEXT,
            nama_ibu TEXT,
            nama_ayah TEXT,
            hp TEXT,
            status TEXT DEFAULT 'Pending'
        )
    """)

    db.commit()
    db.close()


init_db()


# ======================
# ROUTES
# ======================

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/spmb')
def spmb():
    db = get_db()

    data = db.execute("""
        SELECT *,
        (
          strftime('%Y', 'now') - strftime('%Y', tanggal_lahir)
          - (strftime('%m-%d', 'now') < strftime('%m-%d', tanggal_lahir))
        ) as umur
        FROM pendaftar
        ORDER BY tanggal_lahir ASC
    """).fetchall()

    db.close()
    return render_template('spmb.html', data=data)


@app.route('/spmb/daftar')
def daftar():
    print("HALAMAN DAFTAR DIPANGGIL")
    return render_template('daftar_spmb.html')


@app.route('/spmb/simpan', methods=['POST'])
def simpan():
    db = get_db()

    db.execute("""
        INSERT INTO pendaftar (
            nama, nisn, jenis_kelamin, tempat_lahir, tanggal_lahir,
            nik, kk, no_akta, asal_tk,
            alamat, rt, rw, nama_ibu, nama_ayah, hp
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        request.form['nama'],
        request.form['nisn'],
        request.form['jenis_kelamin'],
        request.form['tempat_lahir'],
        request.form['tanggal_lahir'],
        request.form['nik'],
        request.form['kk'],
        request.form['no_akta'],
        request.form['asal_tk'],
        request.form['alamat'],
        request.form['rt'],
        request.form['rw'],
        request.form['nama_ibu'],
        request.form['nama_ayah'],
        request.form['hp'],
    ))

    db.commit()
    db.close()

    return redirect('/spmb')


# ======================
# SELEKSI
# ======================
@app.route('/spmb/seleksi')
def seleksi():
    db = get_db()

    kuota = 28

    # reset
    db.execute("UPDATE pendaftar SET status='Ditolak'")

    # ambil berdasarkan umur (tertua)
    top = db.execute("""
        SELECT id FROM pendaftar
        ORDER BY tanggal_lahir ASC
        LIMIT ?
    """, (kuota,)).fetchall()

    for t in top:
        db.execute("UPDATE pendaftar SET status='Diterima' WHERE id=?", (t['id'],))

    db.commit()
    db.close()

    return redirect('/spmb')


# ======================
# EXPORT EXCEL
# ======================
@app.route('/spmb/export')
def export_excel():
    db = get_db()

    data = db.execute("""
        SELECT *,
        (
          strftime('%Y', 'now') - strftime('%Y', tanggal_lahir)
          - (strftime('%m-%d', 'now') < strftime('%m-%d', tanggal_lahir))
        ) as umur
        FROM pendaftar
        ORDER BY tanggal_lahir ASC
    """).fetchall()

    db.close()

    if not data:
        return "Data kosong"

    wb = Workbook()

    # SHEET DATA
    ws = wb.active
    ws.title = "Semua Data"

    columns = list(data[0].keys())

    ws.append(columns)

    for cell in ws[1]:
        cell.font = Font(bold=True)

    for d in data:
        ws.append([d[col] for col in columns])

    # WARNA STATUS
    if 'status' in columns:
        idx = columns.index('status')

        for row in ws.iter_rows(min_row=2):
            status = row[idx].value

            if status == "Diterima":
                for c in row:
                    c.fill = PatternFill(start_color="C6EFCE", fill_type="solid")
            elif status == "Ditolak":
                for c in row:
                    c.fill = PatternFill(start_color="FFC7CE", fill_type="solid")

    # AUTO WIDTH
    for col in ws.columns:
        max_length = 0
        col_letter = col[0].column_letter

        for cell in col:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))

        ws.column_dimensions[col_letter].width = max_length + 2

    # SHEET GRAFIK
    ws_chart = wb.create_sheet("Grafik")

    diterima = sum(1 for d in data if d['status'] == "Diterima")
    ditolak = sum(1 for d in data if d['status'] == "Ditolak")

    ws_chart.append(["Status", "Jumlah"])
    ws_chart.append(["Diterima", diterima])
    ws_chart.append(["Ditolak", ditolak])

    chart = BarChart()
    chart.title = "Hasil Seleksi SPMB"

    data_ref = Reference(ws_chart, min_col=2, min_row=1, max_row=3)
    cats_ref = Reference(ws_chart, min_col=1, min_row=2, max_row=3)

    chart.add_data(data_ref, titles_from_data=True)
    chart.set_categories(cats_ref)

    ws_chart.add_chart(chart, "E2")

    # SAVE
    file_stream = io.BytesIO()
    wb.save(file_stream)
    file_stream.seek(0)

    return send_file(
        file_stream,
        as_attachment=True,
        download_name="laporan_spmb.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


# ======================
# EXPORT PDF
# ======================
@app.route('/spmb/pdf')
def export_pdf():
    db = get_db()

    data = db.execute("""
        SELECT *,
        (
          strftime('%Y', 'now') - strftime('%Y', tanggal_lahir)
          - (strftime('%m-%d', 'now') < strftime('%m-%d', tanggal_lahir))
        ) as umur
        FROM pendaftar
        ORDER BY tanggal_lahir ASC
    """).fetchall()

    db.close()

    buffer = io.BytesIO()

    doc = SimpleDocTemplate(buffer, pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()

    elements.append(Paragraph("LAPORAN HASIL SELEKSI PPDB", styles['Title']))
    elements.append(Paragraph("SDN 01 BANGLARANGAN", styles['Heading2']))
    elements.append(Spacer(1, 12))

    table_data = [["No", "Nama", "NISN", "Umur", "Alamat", "Status"]]

    for i, d in enumerate(data, start=1):
        table_data.append([
            i,
            d['nama'],
            d['nisn'],
            str(d['umur']) + " th",
            d['alamat'],
            d['status']
        ])

    table = Table(table_data)

    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.grey),
        ('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('GRID',(0,0),(-1,-1),1,colors.black),
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
    ]))

    elements.append(table)

    elements.append(Spacer(1, 40))
    elements.append(Paragraph("Kepala Sekolah", styles['Normal']))
    elements.append(Spacer(1, 60))
    elements.append(Paragraph("(____________________)", styles['Normal']))

    doc.build(elements)

    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name="laporan_ppdb.pdf",
        mimetype="application/pdf"
    )


# ======================
# RUN
# ======================
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050, debug=True)